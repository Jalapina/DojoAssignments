$(document).ready(function(){
console.log('Working');
var pokemon = "http://pokeapi.co/media/img/1.png"
var counter=0;
for(var i=0; i<152; i++){
  counter++;
  var pokemons= pokemon.substring(0,28)+counter+pokemon.substring(29);
  console.log(pokemons);
  $('body').append("<img src="+pokemons+">")
}


});
